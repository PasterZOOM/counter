import React, {useState} from 'react';
import './App.css';
import {Scoreboard} from './Scoreboard';

export type AppPropsType = {
    startValue: number
    maxValue: number
}

const App: React.FC<AppPropsType> = ({startValue, maxValue}) => {

    let [count, setCount] = useState<number>(startValue)

    const Inc = () => {
        if (count < maxValue) {
            setCount(count + 1)
        }
    }

    const Reset = () => {
        setCount(startValue)
    }

    return (
        <>
            <Scoreboard value={count}
                        Inc={Inc}
                        Reset={Reset}
                        startValue={startValue}
                        maxValue={maxValue}
            />
        </>
    );
}

export default App;
