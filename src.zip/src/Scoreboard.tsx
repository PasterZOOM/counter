import React from 'react';
import {Button} from './Button';
import {Counter} from './Counter';
import style from './Scoreboard.module.css'
import {AppPropsType} from './App';

export type ScoreboardPropsType = AppPropsType & {
    value: number
    Inc: () => void
    Reset: () => void
}

export const Scoreboard: React.FC<ScoreboardPropsType> =
    ({value, Inc, Reset, startValue, maxValue}) => {
        return (
            <div className={style.scoreboard}>
                <div className={style.counter}>
                    <Counter value={value} maxValue={maxValue}/>
                </div>
                <div className={style.buttons}>
                    <Button name={'INC'}
                            callBack={Inc}
                            disabled={value === maxValue}/>
                    <Button name={'RESET'}
                            callBack={Reset}
                            disabled={value === startValue}/>
                </div>
            </div>
        )
    }
